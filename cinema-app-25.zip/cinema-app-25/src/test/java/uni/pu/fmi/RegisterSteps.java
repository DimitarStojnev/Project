package uni.pu.fmi;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uni.pu.fmi.services.RegisterService;

import static org.junit.Assert.assertEquals;

public class RegisterSteps {
    private RegisterService registerService;

    private String username;
    private String password;
    private String password2;
    private String email;
    private String message;


    @Given("Потребителя отваря екрана за регистрация")
    public void openRegisterScreen() {
         this.registerService = new RegisterService();
    }
    @When("Въдеде потребителско име {string}")
    public void addUsername(String username) {
        this.username=username;
    }
    @When("Въведе парола {string}")
    public void addPassword(String pass) {
        password=pass;
    }
    @When("Въведе втора парола {string}")
    public void addSecondPassword(String pass2) {
        password2=pass2;
    }
    @When("Въведе имейл {string}")
    public void addEmail(String email) {
       this.email=email;
    }
    @When("Натисне бутона за регистрация")
    public void clickRegisterButton() {
        message=registerService.register(username, password, password2, email);
    }
    @Then("Потребителя вижда съобщение {string}")
    public void checkMessage(String expectedMessage) {
        assertEquals(expectedMessage, message);
    }
}
