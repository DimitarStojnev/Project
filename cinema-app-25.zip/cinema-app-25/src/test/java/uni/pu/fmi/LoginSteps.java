package uni.pu.fmi;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uni.pu.fmi.services.LoginService;

import static org.junit.Assert.assertEquals;

public class LoginSteps {

    LoginService service;
    String password = null;
    String username = null;
    String message = null;

    @Given("Потребителят отваря страницата за вход")
    public void openLoginPage() {
        this.service = new LoginService();
    }
    @When("Потребителят въведе парола {string}")
    public void addPassword(String password) {
        this.password = password;
    }
    @When("натиска бутона за вход")
    public void clickLoginButton() {
        this.message = service.login(username, password);
    }
    @Then("Появява се съобщение {string}")
    public void checkMessage(String expectedMessage) {
        assertEquals(expectedMessage, message);
    }

    @When("Потребителят въвежда потребителско име {string}")
    public void addUsername(String username) {
        this.username = username;
    }
}
