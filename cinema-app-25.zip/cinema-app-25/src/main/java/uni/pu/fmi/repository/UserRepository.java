package uni.pu.fmi.repository;

import uni.pu.fmi.models.User;

import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private static final List<User> users = new ArrayList<>();

    static {
        // Добавяме примерни потребители за тестване на сценарии
        users.add(new User(1L, "admin1", "adminpass", "admin@shop.com", true));
        users.add(new User(3L, "user3", "pass3", "user3@gmail.com", false));
        users.add(new User(5L, "user5", "pass5", "user5@gmail.com", false));
        users.add(new User(7L, "user7", "pass7", "user7@gmail.com", false));
        users.add(new User(12L, "user12", "pass12", "user12@gmail.com", false));
    }

    public List<User> getUsers() {
        return users;
    }

    public void create(User user) {
        users.add(user);
    }

    public User findById(Long id) {
        return users.stream()
                .filter(user -> user.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public User findByUsername(String username) {
        return users.stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }
}
