package uni.pu.fmi.services;

import org.apache.commons.lang3.StringUtils;
import uni.pu.fmi.models.User;
import uni.pu.fmi.repository.UserRepository;

import java.util.List;

public class LoginService {

    public String login(String username, String password) {

        if (StringUtils.isBlank(username) && StringUtils.isBlank(password)) {
            return "Моля, въведете потребителско име и парола.";
        }

        if (StringUtils.isBlank(username)) {
            return "Моля, въведете потребителско име.";
        }

        if (StringUtils.isBlank(password)) {
            return "Моля, въведете парола.";
        }

        UserRepository userRepository = new UserRepository();
        List<User> users = userRepository.getUsers();

        boolean isUserExisting = users.stream()
            .anyMatch(user -> user.getUsername()
                .equals(username) && user.getPassword()
                .equals(password));

        return isUserExisting ? "Успешно влязохте в системата." : "Невалидно потребителско име или парола.";
    }

}
