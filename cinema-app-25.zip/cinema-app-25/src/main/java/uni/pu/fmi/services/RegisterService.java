package uni.pu.fmi.services;

import java.util.*;
import java.util.stream.Collectors;

public class RegisterService {

    private final Map<Long, UserData> users = new HashMap<>();
    private final Map<Long, Product> products = new HashMap<>();
    private final Map<Long, Order> orders = new HashMap<>();
    private final Map<Long, Review> reviews = new HashMap<>();

    private long orderIdCounter = 1;
    private long reviewIdCounter = 1;
    private long productIdCounter = 1;

    // ----- ПОРЪЧКИ -----

    public String finishOrder(long userId) {
        UserData user = users.get(userId);
        if (user == null || user.cart.isEmpty()) {
            return "Количката е празна. Моля, добавете продукти.";
        }
        Order order = new Order(orderIdCounter++, new ArrayList<>(user.cart), "Изпратена");
        user.orders.add(order);
        orders.put(order.id, order);
        user.cart.clear();
        return "Поръчката е приета успешно.";
    }

    public void addToCart(long userId, List<String> productNames) {
        UserData user = users.computeIfAbsent(userId, id -> new UserData());
        for (String name : productNames) {
            products.values().stream()
                    .filter(p -> p.name.equalsIgnoreCase(name))
                    .findFirst()
                    .ifPresent(user.cart::add);
        }
    }

    public List<Order> viewOrders(long userId) {
        return users.getOrDefault(userId, new UserData()).orders;
    }

    public List<Order> filterOrdersByStatus(long userId, String status) {
        return viewOrders(userId).stream()
                .filter(o -> o.status.equalsIgnoreCase(status))
                .collect(Collectors.toList());
    }

    // ----- РЕВЮТА -----

    public String submitReview(long userId, long productId, int rating, String comment) {
        if (comment == null || comment.trim().isEmpty()) {
            return "Моля, въведете коментар.";
        }
        Review review = new Review(reviewIdCounter++, productId, rating, comment);
        reviews.put(review.id, review);
        return "Ревюто е изпратено успешно.";
    }

    public List<Review> getProductReviews(long productId) {
        return reviews.values().stream()
                .filter(r -> r.productId == productId)
                .collect(Collectors.toList());
    }

    public boolean deleteReview(long reviewId) {
        return reviews.remove(reviewId) != null;
    }

    // ----- ПРОДУКТИ -----

    public String addProduct(String name, String description, double price, int stock, String category) {
        if (name == null || name.trim().isEmpty()) {
            return "Името е задължително";
        }
        Product product = new Product(productIdCounter++, name, description, price, stock, category);
        products.put(product.id, product);
        return "Продуктът се запазва успешно";
    }

    public boolean updateProductPrice(long productId, double newPrice) {
        Product product = products.get(productId);
        if (product == null) return false;
        product.price = newPrice;
        return true;
    }

    public List<Product> getVisibleProducts() {
        return products.values().stream()
                .filter(p -> p.stock > 0)
                .collect(Collectors.toList());
    }

    public List<Product> searchProducts(String keyword) {
        return products.values().stream()
                .filter(p -> p.name.toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }

    // ----- Вътрешни класове -----

    static class UserData {
        List<Product> cart = new ArrayList<>();
        List<Order> orders = new ArrayList<>();
    }

    static class Product {
        long id;
        String name;
        String description;
        double price;
        int stock;
        String category;

        public Product(long id, String name, String description, double price, int stock, String category) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.price = price;
            this.stock = stock;
            this.category = category;
        }
    }

    static class Order {
        long id;
        List<Product> items;
        String status;

        public Order(long id, List<Product> items, String status) {
            this.id = id;
            this.items = items;
            this.status = status;
        }
    }

    static class Review {
        long id;
        long productId;
        int rating;
        String comment;

        public Review(long id, long productId, int rating, String comment) {
            this.id = id;
            this.productId = productId;
            this.rating = rating;
            this.comment = comment;
        }
    }
}
